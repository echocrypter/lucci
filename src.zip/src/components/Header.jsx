import React, { useState, useEffect } from 'react';
import Logo from './Logo';
import { useCart } from '../context/CartContext';

export default function Header() {
  const {
    totalCount,
    setIsCartOpen,
    setIsSearchOpen,
    openSalonBooking,
    setIsRunwayOpen,
    activePage,
    navigateTo,
  } = useCart();

  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  /* =========================================================
     SCROLL
  ========================================================== */

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 24);
    };

    window.addEventListener('scroll', handleScroll, {
      passive: true,
    });

    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  /* =========================================================
     RESIZE
  ========================================================== */

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1280) {
        setMobileMenuOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  /* =========================================================
     NAVIGATION
  ========================================================== */

  const handleNavClick = (sectionId, e) => {
    if (e) e.preventDefault();

    setMobileMenuOpen(false);

    if (sectionId === 'leather-goods') {
      navigateTo('pdp', 'il-baule-doro');
      return;
    }

    if (sectionId === 'runway') {
      setIsRunwayOpen(true);
      return;
    }

    if (activePage !== 'home') {
      navigateTo('home');

      window.setTimeout(() => {
        const element = document.getElementById(sectionId);

        if (element) {
          element.scrollIntoView({
            behavior: 'smooth',
            block: 'start',
          });
        }
      }, 100);
    } else {
      const element = document.getElementById(sectionId);

      if (element) {
        element.scrollIntoView({
          behavior: 'smooth',
          block: 'start',
        });
      }
    }
  };

  /* =========================================================
     NAV ITEMS
  ========================================================== */

  const navItems = [
    {
      id: 'collections',
      label: 'Collections',
      page: 'home',
    },
    {
      id: 'leather-goods',
      label: 'Leather Goods',
      page: 'pdp',
    },
    {
      id: 'runway',
      label: 'Runway',
      page: null,
    },
    {
      id: 'archive',
      label: 'The Archive',
      page: null,
    },
    {
      id: 'maison',
      label: 'Maison',
      page: null,
    },
  ];

  const mobileNavItems = [
    {
      id: 'collections',
      label: 'Collections',
      badge: null,
    },
    {
      id: 'leather-goods',
      label: 'Leather Goods',
      badge: "Il Baule D'Oro",
    },
    {
      id: 'runway',
      label: 'Runway Défilé',
      badge: null,
    },
    {
      id: 'archive',
      label: 'The Archive Register',
      badge: null,
    },
    {
      id: 'maison',
      label: 'Maison & Salons',
      badge: null,
    },
  ];

  /* =========================================================
     ICON COLORS
  ========================================================== */

  const iconColor = isScrolled
    ? 'text-[#10251b] hover:text-[#8d7135]'
    : 'text-white hover:text-[#e7cc8b]';

  return (
    <>
      {/* =====================================================
          MAIN NAVBAR
      ====================================================== */}

      <header
        className={`
          fixed
          top-0
          left-0
          w-full
          z-50
          transition-all
          duration-500
          ease-out

          ${
            isScrolled
              ? `
                bg-[#f8f6f1]/90
                backdrop-blur-2xl
                backdrop-saturate-150
                border-b
                border-[#d8d4cb]/80
                shadow-[0_8px_35px_rgba(10,25,17,0.10)]
              `
              : `
                bg-[#07150f]/55
                backdrop-blur-xl
                backdrop-saturate-150
                border-b
                border-white/15
                shadow-[0_8px_35px_rgba(0,0,0,0.18)]
              `
          }
        `}
      >

        {/* ===================================================
            GLASS HIGHLIGHT
        ==================================================== */}

        <div
          className="
            absolute
            inset-x-0
            top-0
            h-px
            bg-white/25
            pointer-events-none
          "
        />

        {/* ===================================================
            NAVBAR CONTENT
        ==================================================== */}

        <div
          className="
            relative
            w-full
            max-w-[1920px]
            mx-auto
            px-5
            sm:px-8
            lg:px-12
            xl:px-16
            h-[76px]
            xl:h-[84px]
            grid
            grid-cols-[1fr_auto_1fr]
            items-center
          "
        >

          {/* =================================================
              LOGO
          ================================================== */}

          <div className="flex items-center justify-start min-w-0">
            <button
              type="button"
              onClick={() => navigateTo('home')}
              className="
                group
                relative
                flex
                items-center
                justify-start
                cursor-pointer
                shrink-0
              "
              aria-label="LUCCI Homepage"
            >

              {/* Logo glass backing */}
              <span
                className={`
                  absolute
                  -inset-x-4
                  -inset-y-3
                  rounded-md
                  pointer-events-none
                  transition-all
                  duration-500

                  ${
                    isScrolled
                      ? 'bg-transparent'
                      : 'bg-white/[0.035]'
                  }
                `}
              />

              <Logo
                className={`
                  relative
                  z-10
                  h-[30px]
                  sm:h-[34px]
                  xl:h-[38px]
                  w-auto
                  max-w-[145px]
                  sm:max-w-[165px]
                  xl:max-w-[185px]
                  object-contain
                  transition-all
                  duration-500
                  group-hover:opacity-75

                  ${
                    isScrolled
                      ? `
                        opacity-95
                        filter-none
                      `
                      : `
                        opacity-100
                        brightness-0
                        invert
                        drop-shadow-[0_2px_10px_rgba(0,0,0,0.55)]
                      `
                  }
                `}
              />
            </button>
          </div>

          {/* =================================================
              CENTER NAVIGATION
          ================================================== */}

          <nav
            className="
              hidden
              xl:flex
              items-center
              justify-center
              gap-7
              2xl:gap-10
              whitespace-nowrap
            "
          >
            {navItems.map(({ id, label, page }) => {
              const isActive = page && activePage === page;

              return (
                <button
                  key={id}
                  type="button"
                  onClick={(e) => handleNavClick(id, e)}
                  className={`
                    relative
                    group
                    py-2

                    font-label-caps-md

                    text-[10px]
                    2xl:text-[11px]

                    tracking-[0.20em]
                    2xl:tracking-[0.24em]

                    uppercase
                    whitespace-nowrap

                    transition-all
                    duration-300

                    cursor-pointer

                    ${
                      isScrolled
                        ? `
                          ${
                            isActive
                              ? 'text-[#10251b]'
                              : 'text-[#24372e] hover:text-[#10251b]'
                          }
                        `
                        : `
                          ${
                            isActive
                              ? 'text-white'
                              : 'text-white/95 hover:text-white'
                          }

                          drop-shadow-[0_2px_5px_rgba(0,0,0,0.65)]
                        `
                    }
                  `}
                >
                  {label}

                  {/* Gold underline */}
                  <span
                    className={`
                      absolute
                      left-0
                      right-0
                      -bottom-0.5
                      h-px
                      bg-[#c7a85d]

                      origin-center

                      transition-transform
                      duration-300

                      ${
                        isActive
                          ? 'scale-x-100'
                          : 'scale-x-0 group-hover:scale-x-100'
                      }
                    `}
                  />
                </button>
              );
            })}
          </nav>

          {/* =================================================
              RIGHT ACTIONS
          ================================================== */}

          <div
            className="
              flex
              items-center
              justify-end
              gap-0.5
              sm:gap-1
            "
          >

            {/* SEARCH */}

            <button
              type="button"
              aria-label="Search Archive"
              onClick={() => setIsSearchOpen(true)}
              className={`
                flex
                items-center
                justify-center

                w-10
                h-10

                rounded-full

                transition-all
                duration-300

                cursor-pointer

                ${iconColor}

                ${
                  isScrolled
                    ? 'hover:bg-black/5'
                    : 'hover:bg-white/10'
                }
              `}
              title="Search Archive"
            >
              <span
                className={`
                  material-symbols-outlined
                  text-[21px]

                  ${
                    !isScrolled
                      ? 'drop-shadow-[0_2px_5px_rgba(0,0,0,0.65)]'
                      : ''
                  }
                `}
              >
                search
              </span>
            </button>

            {/* ACCOUNT */}

            <button
              type="button"
              aria-label="Private Client Account"
              onClick={() => openSalonBooking('Firenze')}
              className={`
                hidden
                sm:flex

                items-center
                justify-center

                w-10
                h-10

                rounded-full

                transition-all
                duration-300

                cursor-pointer

                ${iconColor}

                ${
                  isScrolled
                    ? 'hover:bg-black/5'
                    : 'hover:bg-white/10'
                }
              `}
              title="Private Salon Account"
            >
              <span
                className={`
                  material-symbols-outlined
                  text-[21px]

                  ${
                    !isScrolled
                      ? 'drop-shadow-[0_2px_5px_rgba(0,0,0,0.65)]'
                      : ''
                  }
                `}
              >
                person
              </span>
            </button>

            {/* SHOPPING BAG */}

            <button
              type="button"
              aria-label="Salon Acquisition Bag"
              onClick={() => setIsCartOpen(true)}
              className={`
                relative

                flex
                items-center
                justify-center

                w-10
                h-10

                rounded-full

                transition-all
                duration-300

                cursor-pointer

                ${iconColor}

                ${
                  isScrolled
                    ? 'hover:bg-black/5'
                    : 'hover:bg-white/10'
                }
              `}
              title="Acquisition Bag"
            >
              <span
                className={`
                  material-symbols-outlined
                  text-[21px]

                  ${
                    !isScrolled
                      ? 'drop-shadow-[0_2px_5px_rgba(0,0,0,0.65)]'
                      : ''
                  }
                `}
              >
                shopping_bag
              </span>

              {totalCount > 0 && (
                <span
                  className="
                    absolute
                    top-0
                    right-0

                    min-w-[17px]
                    h-[17px]

                    px-1

                    bg-[#8f1830]
                    text-white

                    text-[9px]

                    flex
                    items-center
                    justify-center

                    rounded-full

                    leading-none
                    font-bold

                    border
                    border-white/40

                    shadow-[0_2px_8px_rgba(0,0,0,0.25)]
                  "
                >
                  {totalCount}
                </span>
              )}
            </button>

            {/* MOBILE MENU */}

            <button
              type="button"
              className={`
                xl:hidden

                flex
                items-center
                justify-center

                w-10
                h-10

                rounded-full

                transition-all
                duration-300

                cursor-pointer

                ${iconColor}

                ${
                  isScrolled
                    ? 'hover:bg-black/5'
                    : 'hover:bg-white/10'
                }
              `}
              onClick={() => setMobileMenuOpen((open) => !open)}
              aria-label={
                mobileMenuOpen
                  ? 'Close Navigation Menu'
                  : 'Open Navigation Menu'
              }
              aria-expanded={mobileMenuOpen}
            >
              <span
                className={`
                  material-symbols-outlined
                  text-[24px]

                  ${
                    !isScrolled
                      ? 'drop-shadow-[0_2px_5px_rgba(0,0,0,0.65)]'
                      : ''
                  }
                `}
              >
                {mobileMenuOpen ? 'close' : 'menu'}
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* =========================================================
          MOBILE MENU
      ========================================================== */}

      {mobileMenuOpen && (
        <div
          className="
            fixed
            inset-0
            z-[60]

            bg-[#071a11]
            text-[#fbf9f5]

            flex
            flex-col
            justify-between

            px-6
            sm:px-10
            pb-8

            overflow-y-auto

            animate-fade-in

            xl:hidden
          "
          style={{
            paddingTop:
              'calc(6.5rem + env(safe-area-inset-top, 0px))',
          }}
        >

          <div className="flex flex-col space-y-7 sm:space-y-9">

            {/* MOBILE HEADER */}

            <div
              className="
                flex
                items-center
                justify-between

                border-b
                border-white/15

                pb-5
              "
            >
              <span
                className="
                  font-label-caps-sm

                  text-[10px]
                  sm:text-xs

                  tracking-[0.28em]

                  text-[#e7cc8b]

                  uppercase
                  font-semibold
                "
              >
                Maison Lucci Firenze
              </span>

              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="
                  text-[#e7cc8b]

                  text-[10px]

                  uppercase
                  tracking-[0.25em]

                  flex
                  items-center
                  gap-2

                  p-1

                  cursor-pointer
                "
              >
                Close

                <span className="material-symbols-outlined text-base">
                  close
                </span>
              </button>
            </div>

            {/* MOBILE NAVIGATION */}

            <nav className="flex flex-col">
              {mobileNavItems.map(
                ({ id, label, badge }, index) => (
                  <button
                    key={id}
                    type="button"
                    onClick={(e) => handleNavClick(id, e)}
                    className="
                      group

                      text-left

                      py-5

                      border-b
                      border-white/10

                      cursor-pointer

                      flex
                      items-center
                      justify-between

                      gap-4
                    "
                  >
                    <span
                      className="
                        text-2xl
                        sm:text-3xl

                        font-light

                        tracking-tight

                        group-hover:text-[#e7cc8b]

                        transition-colors
                      "
                    >
                      <span
                        className="
                          text-[#e7cc8b]/40
                          text-xs
                          mr-4
                        "
                      >
                        0{index + 1}
                      </span>

                      {label}
                    </span>

                    {badge && (
                      <span
                        className="
                          shrink-0

                          text-[8px]

                          uppercase

                          tracking-[0.18em]

                          text-[#e7cc8b]

                          px-2.5
                          py-1.5

                          border
                          border-[#e7cc8b]/35
                        "
                      >
                        {badge}
                      </span>
                    )}
                  </button>
                )
              )}
            </nav>

            {/* PRIVATE SALON */}

            <div className="pt-2">
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  openSalonBooking('Firenze');
                }}
                className="
                  w-full

                  py-4

                  bg-[#e7cc8b]
                  text-[#092116]

                  text-[10px]

                  uppercase

                  tracking-[0.2em]

                  font-semibold

                  hover:bg-[#fbf9f5]

                  transition-colors

                  cursor-pointer
                "
              >
                Request Private Salon Appointment
              </button>
            </div>
          </div>

          {/* MOBILE FOOTER */}

          <div
            className="
              border-t
              border-white/15

              pt-6
              mt-10

              space-y-4
            "
          >
            <div
              className="
                flex
                flex-col
                sm:flex-row

                justify-between
                sm:items-center

                gap-3

                text-[9px]
                sm:text-[10px]

                text-white/60

                tracking-[0.18em]

                uppercase
              "
            >
              <span>
                Firenze • Milano • Paris • Tokyo • New York
              </span>

              <span
                className="
                  text-[#e7cc8b]
                  font-light
                "
              >
                Client Hotline: +39 055 839 2000
              </span>
            </div>
          </div>
        </div>
      )}
    </>
  );
}